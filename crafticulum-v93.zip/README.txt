COURSE CREATOR - SELF-HOSTED VERSION

UPDATING
  Updates don't include config.php, so upload everything in the zip and your API
  key and password stay as they are. If an update ever needs a new setting, it
  will say so clearly and list exactly what to add.

WHAT'S IN THE ZIP
  index.html     The front page: what Crafticulum is, who it's for, the prices
  app.html       The app itself (at /app)
  billing.php    Plans and payments: talks to Stripe (see PLANS AND PAYMENTS)
  ai.php         Sends lesson requests to Claude using your API key (kept on the server)
  store.php      Saves your lessons and sequences on the server (in a data folder)
  share.php      Student links: lesson pages, unit pages and assessments
  backup.php     Daily backups of the data folder, and clearing old student answers
  auth.php       Google sign-in, staff accounts and departments
  auth-lib.php   Works out who is signed in and what they can do (used by the others)
  assets/        The PowerPoint and Word templates, loaded only when you download
  student.html   The page students see when they open a link
  about.html (now just forwards to the front page), terms.html, privacy.html,
  cookies.html, pages.css, pages.js
                 The public pages (see THE PUBLIC PAGES)
  setup.php      First-time setup on a new site. Does nothing once config.php exists
  config.example.php  Settings template. Only used on a first install (see below)
  .htaccess      Stops anyone opening config.php from the web
  manifest.webmanifest, sw.js and the icon files
                 Let you install Crafticulum as an app (see INSTALL AS AN APP)
  marker/        Second Marker's code and its server file (see SECOND MARKER)
  quiz/          The quiz room: phone quiz with initials and an end-of-quiz report
  README.txt     This file

SET UP (cPanel, about 10 minutes)
1. Make sure the site runs PHP 8.0 or newer with the curl and zip extensions
   (cPanel > Select PHP Version / MultiPHP Manager). Most hosts have them on already.
   zip is only needed for the automatic backups.
2. File Manager > public_html: create a folder, e.g. "lessons", and upload
   everything from this zip into it, keeping the quiz folder as it is.
   (Turn on "Show hidden files" so you can see .htaccess after uploading.)
3. FIRST INSTALL ONLY: in File Manager, copy config.example.php and name the
   copy config.php. Then edit config.php:
     ANTHROPIC_API_KEY  your key from console.anthropic.com
     TEACHER_PASSWORD   a strong password you'll type to write lessons
     CLAUDE_MODEL       leave as it is unless you want a different model
4. Visit https://yourdomain/lessons/
   The first time you build a lesson it asks for the teacher password.

WHAT WORKS DIFFERENTLY FROM THE CLAUDE VERSION
- Writing lessons, starters, quizzes, task sheets, brief support versions and the
  MKC lesson plan all go through ai.php. Each request uses your Anthropic API
  credit. MAX_REQUESTS_PER_HOUR in config.php caps it per teacher.
- Downloads (PowerPoint, Word, images) save straight to the computer.
- The lesson library is saved on your server, so it's the same at Medway and
  Maidstone once you sign in.
- The phone quiz uses the quiz room in ./quiz/ automatically: students scan, type
  initials and answer, and you get a report when you end it. Ending deletes the
  answers from the server. Anything not ended is deleted after 6 hours.
- The board, timers, tools, display options and overlays work exactly the same.

PLANNING (SEQUENCE OF LEARNING) AND BUILDING LOTS OF LESSONS
- Every unit has a week-by-week sequence ready to go. You can build one lesson,
  a whole unit, or every unit in a level. It builds them one after another.
- Each lesson is one request to Claude. MAX_REQUESTS_PER_HOUR in config.php
  (60 to start with) limits how fast a big build can go. Raise it if you want
  whole units built quicker. When the limit is hit the build waits and carries on.
- Lessons, sequences, groups and term dates are saved on your server in a
  folder called data, next to store.php. The page asks for the teacher password
  when it opens, then loads them. They follow you between computers.
- If saving fails, create the data folder yourself in File Manager and set its
  permissions to 755. Back that folder up now and then: it is your library.

STUDENT LINKS
- On a lesson, Share gives you a Student page link (tasks and independent study,
  no teacher notes or answers) and a Quiz link for the exit quiz.
- In Planning, Share with students gives you a Unit page (every built lesson by
  week) and an End of unit assessment.
- Students open the links without a password. Send them by email or Discord, or
  show the QR code on the board.
- Assessments are marked on the server, so the answers never reach a student's
  browser before they hand in. Results are saved with the name they type, in
  data/share. Clear results or Stop sharing deletes them.
- Shared pages update themselves when you edit a lesson or build more of a unit.
- Student pages show the assignment dates, with the next deadline at the top,
  and a button to add every deadline to their calendar with reminders.
- Cover teacher link (Share menu on a lesson): a read-only page with your plan,
  the starter answers, the quiz answers, the downloads and a simple board view.
  It has the answers, so send it to the cover teacher only.

LIVE LESSONS
- On the board, open the Students tab and press Go live (or Share > Go live).
  Students' lesson pages, and unit pages, then follow the slide, the task and
  the timer you show. They can switch Follow off. Press the red Live button on
  the board to stop. It stops on its own after 15 minutes with no board open.
- Students type their name once, tick off steps and press I've finished this
  task. The Tasks and Students tabs on the board show who's finished what.
  I need help puts them in the orange Help list on the board. Press Helped
  to clear them. Progress is kept in data/share/live for 2 hours.

LESSON RESOURCES
- On a lesson's Overview tab, add links (YouTube, websites) or upload files:
  PDFs, images, MP4, MP3 and Office files up to 25 MB. They show on the board's
  Resources tab and on the student page. Files are kept in data/share/res.
- If uploads fail on big files, your host's PHP upload_max_filesize and
  post_max_size are lower than the file. Raise them in cPanel > Select PHP
  Version > Options, or add a link instead.

WEEKLY RETRIEVAL QUIZ, RESULTS, LEARNER NEEDS, SHARING UNITS
- This week has a Weekly retrieval quiz: questions from lessons already taught,
  picked more often where the class did badly. Share it as a link (students
  keep the same link every week) or show it on the board.
- Results shows quiz and assessment scores by unit and criterion, with a
  Catch-up lesson button for weak criteria.
- Settings > Learner needs: pick what each group needs (EAL, dyslexia and so
  on). Every lesson built for that group has the support built in.
- Planning > Download > Unit for a colleague saves a file with the unit's
  sequence and lessons. Your colleague imports it in Settings > Backup.

DISCORD
- Settings > Discord: add a channel's webhook URL (channel settings >
  Integrations > Webhooks > New Webhook > Copy Webhook URL).
- Every Share window then has Post to Discord, which posts the link, the next
  deadline and the QR code. The webhook URLs stay on your server in data/share.
- Needs the PHP curl extension, the same as writing lessons.

INSTALL AS AN APP
- Settings > Install as an app, or the install icon in Chrome or Edge's address
  bar. On iPhone: Share > Add to Home Screen.
- The app opens in its own window and still opens when the Wi-Fi drops. Building
  lessons and sharing need the internet.

LESSON HISTORY
- Every lesson keeps its last 8 versions (saved when you regenerate, try new
  ideas or edit). Press History under a lesson to restore one.

STAFF ACCOUNTS
- Super admin: sees and manages everything, in every department. Set by
  SUPER_ADMINS in config.php.
- Head of department: approves new accounts, adds staff to their department,
  chooses who can edit lessons by hand, and builds with Claude.
- Teacher: opens every lesson and unit in the department, puts them on the
  board and shares them with students, but can't build with Claude. Can edit
  lessons by hand only if their head of department switches it on.
- Each department has its own lessons, units, term dates and staff. Each person
  keeps their own groups, taught ticks, notes, start weeks, student links and
  results.

HOW PEOPLE SIGN IN
- Email and password: anyone can press Ask for an account. They wait until a
  head of department or super admin approves them in Settings > Team. If email
  is set up, they confirm their address first and get an email when approved.
- Email links (no password): with email set up, people can leave the password
  blank when they ask for an account, and press Email me a sign-in link on the
  sign-in page any time. The link works once, for 15 minutes. Their approval
  email includes their first sign-in link. People with a password can use it too.
- Google, Microsoft or OpenID Connect: the first time someone signs in, it
  becomes a request to approve in the same way. People already on the team go
  straight in. The same email works with every way of signing in.
- Two-step codes: anyone with a password can turn on authenticator app codes
  in Settings > Your account, and gets 8 one-time recovery codes. Heads of
  department can turn them off for someone who's lost their phone.
- Forgotten passwords: with email set up, Forgot your password sends a link.
  Without it, a head of department presses Reset link in Settings > Team and
  sends the link on. Links work once.
- 8 wrong passwords in a row locks that email for 15 minutes.
- Settings > Team > Add someone adds a person straight away, and can give you
  a link (and email it) so they choose their own password.
- The admin password in config.php signs you in as a super admin until Google,
  Microsoft or OpenID Connect is set up, or you have your own password. Set PASSWORD_BACKUP to true to keep it after that.

SIGN IN WITH GOOGLE (optional, about 10 minutes)
1. Go to console.cloud.google.com and create a project, e.g. "Crafticulum".
2. APIs & Services > OAuth consent screen: choose External, give it a name and
   your email, save. Then press Publish app so any Google account can sign in.
3. APIs & Services > Credentials > Create credentials > OAuth client ID.
   Type: Web application. Under Authorised JavaScript origins add your site's
   address with no folder and no slash at the end, e.g.
   https://hopeful-lime-horse.185-199-220-70.cpanel.site
   No redirect URIs are needed. Press Create and copy the Client ID.
4. In config.php set GOOGLE_CLIENT_ID to the Client ID.

SIGN IN WITH MICROSOFT (optional, about 10 minutes)
1. Go to entra.microsoft.com (or portal.azure.com) > App registrations > New
   registration. Name: Crafticulum. Supported account types: Accounts in
   any organisational directory and personal Microsoft accounts.
2. Redirect URI: choose Web and enter your site's address followed by
   auth.php?a=ms_cb, e.g.
   https://hopeful-lime-horse.185-199-220-70.cpanel.site/auth.php?a=ms_cb
   (include the folder if Crafticulum is in one).
3. Copy the Application (client) ID into MS_CLIENT_ID in config.php.
4. Certificates & secrets > New client secret. Copy the Value (not the ID)
   into MS_CLIENT_SECRET. Secrets expire: set a reminder to make a new one.
5. Leave MS_TENANT as common. To allow only one organisation, put its
   tenant ID there instead.

SIGN IN WITH OPENID CONNECT (optional: Okta, Auth0, Keycloak, OneLogin and others)
1. In your provider, create an application of type Web (OpenID Connect,
   authorisation code). Allow the scopes openid, email and profile.
2. Sign-in redirect URI: your site's address followed by auth.php?a=oidc_cb, e.g.
   https://hopeful-lime-horse.185-199-220-70.cpanel.site/auth.php?a=oidc_cb
3. In config.php set:
     OIDC_ISSUER         the issuer URL, e.g. https://your-org.okta.com or
                         https://keycloak.example.com/realms/college
     OIDC_CLIENT_ID      the client ID
     OIDC_CLIENT_SECRET  the client secret
     OIDC_NAME           what the button says, e.g. College login
   Crafticulum reads the rest from the provider's discovery document.
4. The provider must share the person's email address (and not mark it as
   unconfirmed), so it can be matched to someone on the team.

SENDING EMAILS (optional)
- Easiest: fill in SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS and MAIL_FROM with
  an email account's settings. For a cPanel email account these are shown in
  cPanel > Email Accounts > Connect Devices (usually port 587 with 'tls', or
  465 with 'ssl').
- Or leave SMTP_HOST empty and set only MAIL_FROM to use the host's own mail.
  These are more likely to land in junk.
- Without either, everything still works: heads of department copy links and
  send them on themselves.

NEW SETTINGS IN CONFIG.PHP
  Add whichever of these you want to the end of config.php. All are optional,
  and anything you leave out is simply switched off:
     const GOOGLE_CLIENT_ID = '';
     const SUPER_ADMINS = ['your.email@example.com'];
     const PASSWORD_BACKUP = false;
     const MS_CLIENT_ID = '';
     const MS_CLIENT_SECRET = '';
     const MS_TENANT = 'common';
     const MAIL_FROM = '';
     const SMTP_HOST = '';
     const SMTP_PORT = 587;
     const SMTP_USER = '';
     const SMTP_PASS = '';
     const SMTP_SECURE = 'tls';
     const OIDC_ISSUER = '';
     const OIDC_CLIENT_ID = '';
     const OIDC_CLIENT_SECRET = '';
     const OIDC_NAME = 'College login';

BACKUPS AND STUDENT DATA
- The first time Crafticulum is opened each day, the server zips the data
  folder into data/backups and keeps the last 14. Download any of them from
  Settings > Automatic backups, or press Back up now.
- To restore one, unzip it into the data folder in File Manager (replace the
  files). Keep a copy somewhere else too, now and then.
- Settings > Student data sets how long students' names and answers are kept
  (Never, 30 days up to 1 year), and has a button to delete them all now.

KEEPING IT SAFE
- Never share config.php. The API key never goes to the browser.
- Students can open the quiz pages but can't use ai.php without the teacher password.
- If the password ever leaks, change TEACHER_PASSWORD in config.php.


FIRST-TIME SETUP ON A NEW SITE
------------------------------
On a brand new site you don't need to make config.php yourself. Upload the
files, open the site, and it asks for your college's name, your first
department, and the name, email and password of the person in charge (the
super admin). It then writes config.php for you and signs you in.

After that, everything else is set on screen in Settings:
  Your college   the name, logo and colour
  Site setup     Claude's API key, email, and Google, Microsoft or college sign-in

A setting saved on screen is used before the same setting in config.php, so an
existing site can leave its config.php alone and still change things on screen.
setup.php refuses to do anything once config.php exists.


THE SITE'S ADDRESS
------------------
Main address:       https://crafticulum.co.uk
Temporary address:  https://hopeful-lime-horse.185-199-220-70.cpanel.site

Both addresses open the same site. Links in emails and links given to students
(lesson pages, class pages, quizzes, QR codes) use the main address as soon as
the site answers there. Until then they use the address you are on, so nothing
breaks while the domain is being pointed at the server.

If you use Google, Microsoft or college sign-in, add the redirect addresses for
BOTH site addresses in each provider. Settings, Site setup lists them.

To change either address, use Settings, Site setup, Site address, or add these
two lines to config.php:

  const SITE_URL = 'https://crafticulum.co.uk';
  const SITE_URL_TEMP = 'https://hopeful-lime-horse.185-199-220-70.cpanel.site';

An address saved in Settings is used before the one in config.php.


A NEW SITE STARTS EMPTY
A site made with the first-time setup has no built-in units, no built-in
assignment briefs and none of the first college's forms, term dates or tutorial
themes. The Start page asks for the first subject, which is added by uploading
its specification. Until you upload your own files in Settings, Your documents,
the lesson plan, PowerPoint and sequence of learning come out on plain layouts.

The site this software began on keeps its Esports and IT units and its own
documents. Nothing changes there.


THE PUBLIC PAGES
index.html     the front page: what Crafticulum is, who it's for, how to get it
               (it used to be about.html, which now forwards here)
terms.html     terms of use
privacy.html   privacy notice
cookies.html   what is stored on a device

They pick up your name, logo, colour and contact email from Settings, Your
college. In the same place you choose whether people who aren't signed in see
the front page first or go straight to the sign-in page. Anyone who has signed
in on that device before always goes straight to the sign-in page.

The terms and privacy notice were written to match what the software does, but
they are a starting point. Have whoever looks after data protection for your
organisation read them, and edit the files to suit.


USAGE AND COST
Settings, Usage and cost shows how many requests each department and person
has made to Claude each month, and how much text was sent and written. Type in
your model's prices (per million tokens, from Anthropic's pricing page) to see
a rough cost. You can set the most to spend in a month, the most requests in a
month, and the most requests for each department. When a limit is reached,
building with Claude stops until the 1st or until you raise the limit. Counting
starts from the day this version is installed. Your Anthropic bill is always
the real figure.

Nothing needs adding to config.php for any of this.


SECOND MARKER
Second Marker checks a learner's work against the unit's criteria, suggests a
decision and feedback for each one, and fills in the assessment record and the
internal verification forms. The assessor always makes the final decision.

It is off until a head of department, subject leader or the super admin
switches it on for their department, in Settings, Second Marker. There they
also choose:
  - who can use it: leaders only, or teachers as well
  - the model, or let each person choose
  - whether marking a class set and IV sampling are offered (IV is leaders only)
  - anonymous marking only
  - whether PDFs always go with personal details hidden
  - the ending for learner email addresses
  - their own marking guidance, which is added to every check
  - whether the criteria most often not met are shown on the Results page

Once it's on, Second Marker is in the main menu and opens inside Crafticulum,
with the same look and the same light or dark mode. It starts on the unit you
were last working on, and uses the same subjects, units, criteria, assignment
briefs and hand-in dates as the rest of the site. Each person's own marking
choices are in Settings, Second Marker, under Your marking.

It uses the site's Claude key through marker/api.php, so nobody needs a key of
their own, and it counts towards Usage and cost and the monthly limits. Marking
a long piece of work costs more than building a lesson.

Second Marker has no copy of its own of the courses. The subjects, levels,
units, criteria, assignment briefs and their dates are read from Crafticulum
each time it opens, so adding a subject, uploading a brief or changing a
hand-in date shows up in marking straight away. Planning has a Mark work button
for each assignment, which opens marking on that unit and brief.

Second Marker is part of Crafticulum's own page. There is no separate page or
frame: its code is one file, marker/sm.js, which the app loads the first time
someone opens Second Marker. The marker folder now needs only these files:

  sm.js        Second Marker itself
  api.php      Passes checks to Claude with the site's key, and keeps the
               met or not met counts (no names)
  index.php    Sends old links to the right place
  .htaccess and .user.ini

Anything else left in the marker folder from an earlier version (app.html,
hosted.js, hosted-ui.js, meta.js, units.js, briefs.js, batch.js, iv.js and the
other .js files) is no longer used and can be deleted.

Learner work is sent to Claude to be checked and is NOT stored on your server.
Names, ID numbers, email addresses, phone numbers and postcodes are replaced
before it is sent. Drafts stay in the marker's browser, kept apart for each
member of staff. The only thing kept on the server is which criteria each
finished piece of work met, with no name or ID. Check this fits your college's
data protection rules before switching it on.

Big PDFs: the marker folder asks PHP to accept uploads up to 40 MB. If a large
file is refused, ask your web host to raise post_max_size to 40M.


STAYING SIGNED IN
People stay signed in for 30 days on a device they use, and each day they use
it starts the count again. Change the number of days in Settings, Site setup,
Staying signed in. Signing out always ends it straight away, and takes you back
to the front page.

Sign-ins are now kept in data/_sessions, in this site's own folder, with the
site's own cookie (ccsid). Everyone is asked to sign in once after this update.


STARTING FROM YOUR TEAM'S LESSONS
Before a new lesson is built, the lessons your department already has for that
unit are offered first. You can open one, use one as the base for the new
lesson, or build a new one. Using one as the base keeps its structure and
activities and changes only what you asked for; the original is left alone and
the new lesson says which one it was based on.

Every new lesson, including a whole sequence, is also written to match the
department's existing lessons for that unit and not repeat their starters,
tasks or quiz questions. Regenerating a lesson doesn't ask.

Heads of department and subject leaders can switch this off in Settings,
Department rules, Start from our lessons.


MARKING TRACKER, IV PLAN AND FEEDBACK INTO PLANNING
Second Marker's page now has three parts: Mark work, Tracker and IV plan.

Pick the group before you mark. The tracker then shows, for each group and
assignment: the hand-in date, how many handed in (you type this in, as hand-ins
happen outside Crafticulum), how many are marked, how many need to resubmit and
how many have been sampled. The IV plan (heads of department) shows what's been
marked against what's been sampled this academic year, by assessor, unit and
grade, with the gaps listed at the top. Set the share you aim to sample there.

On Planning, the criteria learners miss most in marking show for that unit,
with a button that sets up a catch-up lesson.

All three count from what's marked in Second Marker, and need "Keep results to
improve teaching" switched on in Settings, Second Marker. No learner names, IDs
or work are kept: only the unit, assignment, group, grade and which criteria
were met. IV sampling done on paper isn't counted.


SET-UP CHECKLIST
The super admin's Start page has a checklist for a new college, with a progress
bar. Each row goes to the right part of Settings. Hide it with the cross and
bring it back from Settings, Your college.


A BACKUP OFF THE SERVER
Settings, Automatic backups, A copy off this server. Two ways, use either or
both:

1. Send it to a folder you own. Give the address of a WebDAV folder (Nextcloud,
   ownCloud, Box, pCloud or a college file server), a user name and a password
   or app password. Today's backup is sent the first time someone opens
   Crafticulum each day. Press Send a copy now to check it works. The address
   has to start with https://

2. Have another computer fetch it. Make a private link and put it in a
   scheduled task or backup service, for example:
     curl -fo crafticulum-backup.zip "the link"
   Anyone with the link can download everything, so treat it like a password.
   Making a new link stops the old one working.

Settings warns you if every backup is on the server, if the last copy failed,
or if none has left the server for three days. A backup holds everything on the
site including its settings, so keep it somewhere private.


ERROR LOG
Settings, Error log (super admin only) lists things that went wrong for anyone
on the site: errors in a browser, on the server, from Claude, from email and
from backups. It keeps what the page was doing, the person's role and
department and their browser. It never keeps what was typed, learner work,
email addresses or keys. The newest 500 or so lines are kept in
data/_errors.jsonl. Clear the log with the button.


DEMO
Off unless you switch it on in Settings, Site setup, Demo (type on). The front
page then shows a Try the demo button. Visitors get no account of their own:
they all share one sample department, signed in as "Demo visitor".

The demo can't change settings, people or accounts, send email, share anything
with students or use Second Marker, and it never shows your college's name or
logo. It's emptied the first time someone opens it each day. Building with
Claude is off unless you allow a number of lessons a day in the same place,
which is shared by all visitors and comes out of your Claude credit.

On a site with built-in subjects the demo shows those subjects and uses that
site's documents. Switch it off by typing off in the same box.


SECOND MARKER'S FIRST TWO STEPS
The Unit step and the Learner step are now Crafticulum's own screens, with the
same pickers as the lesson form: subject buttons, level and unit lists, the
assignment, and the criteria tick list with All, None and learning aim buttons.
A green tick shows criteria already taught in your saved lessons, and "Often
missed" shows criteria learners have missed in marking so far.

The brief, assessor guidance, work you've already marked, the resubmission
section and the upload step are the app's own screens too. The class set card,
the checks, the criteria desk and the export step are still the marker's own.
Nothing about how marking works has changed.


CLEAN ADDRESSES AND SEARCH ENGINES
The .htaccess file in this folder now gives every page a clean address:

  /                 the page about Crafticulum for visitors, the app once
                    you're signed in
  /about /contact /terms /privacy /cookies
  /signin           the sign-in page
  /this-week /lessons /planning /results /second-marker /settings
  /s/CODE           a student's lesson or class page
  /sitemap.xml and /robots.txt

Every old address still works. about.html and the other public pages move to
the new address on their own, and student links and QR codes already given out
(student.html?id=...) carry on working. New student links use the short form.

For search engines and link previews, the public pages now carry their full
address, a share picture (og.png) and structured data: the organisation, the
site, the app, the questions and answers on the front page, and a breadcrumb on
the legal pages. It is built by page.php from what the pages themselves say.
It describes Crafticulum only. A college's own name, logo and details are never
put in it, even when the front pages show them. The app's own pages and student
pages are marked not to be listed.

This needs Apache's mod_rewrite, which almost every cPanel host has. If yours
doesn't, the app notices, keeps the old addresses, and nothing breaks. Upload
.htaccess along with the rest: it starts with a dot, so some file managers hide
it until you switch on "show hidden files".

After uploading, check three things: your address shows the front page when
you're signed out, yoursite/planning opens Planning when you're signed in, and
yoursite/sitemap.xml lists your pages. Then add the sitemap in Google Search
Console. If the whole site shows an error straight after uploading, your host
doesn't allow one of the lines in .htaccess: delete everything from "Clean
addresses" to the end of that file and it's back to how it was.


CONTACT AND SUPPORT
There is a contact page at /contact (contact.html) for help, problems, feedback
and enquiries. It is linked from the front page, the bottom of every public
page, and Help and feedback in the app's menu. Signed-in staff have their name
and email filled in, and the message notes which page they came from.

Every message is kept on the site and listed in Settings, Messages (super admin
only), where you can reply, mark it as done or delete it. A reply written
there is emailed to the person with their message underneath, and is kept under
the message so you can see what was said. It needs email set up in Site setup;
without it the button opens your own email program instead. If email is
set up, each one is also sent to the contact email in Settings, Your college
(or to the super admins if none is set), and replying to that email goes
straight to the person who wrote.

To keep robots out, the form has a hidden box and a short wait, and one place
can send five messages an hour. The newest 500 messages are kept.


DIAGRAMS AND PICTURES IN LESSONS
New lessons get visuals in the teaching content, tied to the unit and the
criteria being taught.

Diagrams: Claude describes the diagram (a flow of steps, a cycle, a comparison,
a breakdown, a timeline or layers) and Crafticulum draws it, so every diagram
matches the lesson's own wording and the app's look. Every lesson that teaches
new content is asked for at least one.

Pictures: where a real photograph would help, Claude gives a few search words
and the app finds a freely licensed photo on Wikimedia Commons and shows it
with its credit and licence. Logos, screenshots and named people are never
asked for. On the Teach tab you can press Different picture, Remove picture or
Remove diagram. Check each picture before you teach with it: it is the first
good match for the search, not something a person chose.

They show on the Teach tab, on the board (Show the diagram, Show the picture),
on the student page, and each gets its own slide in the PowerPoint.

Heads of department can switch pictures off in Settings, Department rules.
Diagrams stay on. Lessons built before this update have none until they are
regenerated or given New teaching content.


REGENERATE EVERY LESSON
The year planner on Planning has Regenerate every lesson, next to Build every
unit. It writes every built lesson again with the same settings and builds any
that are missing. Press it twice to confirm. Lessons keep their place and the
links you have shared keep working, but changes made by hand are replaced.
Each lesson is a full build, so a whole year uses a lot of Claude credit.
Stop at any time with the Stop button.


COLLEGES AND WHO CAN DO WHAT
One site can now hold several colleges. Each college has its own name, logo,
colour, contact email, departments, staff, subjects and lessons, and none can
see another's.

Super admin
  Looks after the whole site and every college. Adds colleges and their
  managers in Settings, Colleges, sets a monthly limit for each, can switch a
  college off (its staff can't sign in until it's back on), and can step into
  any college with "Work in this college". Only the super admin sees Site
  setup, backups, the error log, messages and prices.

College manager
  Like the super admin, but for one college. Sets the college's name, logo,
  colour and contact email, adds its departments, adds and approves its heads
  of department and teachers and chooses what each can do, sees the college's
  usage, and can work in any of its departments. Can't see the site's own
  settings, other colleges, or other managers.

Head of department or subject leader, and teacher
  As before, inside their own department.

What happens to the site you already have: it becomes one college holding
every department you had, with the same name, logo, colour, subjects and
people. Nothing moves and nobody has to do anything. Your own account is still
the super admin.

A new college starts with no subjects: its staff upload their own
specifications. Student pages carry the name, logo and colour of the college
whose teacher shared them. With more than one college on the site, the sign-in
page and public pages always show Crafticulum only, and Settings, Your college
gains "Who runs this site" and the site's own contact email for the terms and
privacy pages.

To add a college: Settings, Colleges, Add a college. Give its name, its first
department and its manager's email. The manager is emailed a link to choose a
password.


THE APP NOW LIVES AT /app
Your site's own address (crafticulum.co.uk) is now the front page for everyone.
The app is at /app, and that's where Sign in goes. Nothing needs doing:
  - Old links still work. /about and about.html go to the front page. Links
    from old emails (sign-in links, password resets, invitations) and old
    bookmarks to index.html#... are sent on to the app.
  - /signin, /lessons, /planning, /settings and the rest are unchanged.
  - Student links and QR codes are unchanged.
  - People who installed it as an app keep it; it opens at /app from now on.
After uploading, check: your address shows the front page, Sign in takes you
to /app, and signing in with Google or Microsoft still comes back signed in.
The redirect addresses you gave Google and Microsoft have not changed.


PLANS AND PAYMENTS
You can charge for Crafticulum with monthly plans, paid by card through Stripe.
It is OFF until you switch it on, and while it is off nothing changes.

The plans (you can change every price and limit):
  Free          GBP 0         1 person, 1 department, 10 builds, 2 Second Marker checks a month
  Teacher       GBP 4.99/mo   1 person, 1 department, 100 builds, 40 checks a month
  Department    GBP 49/mo     10 people, 1 department, 600 builds, 300 checks a month
  Institution   custom quote  no limits; you set it by hand

A build is one request to Claude. A lesson is usually one; a quiz, a set of
slides or a fact check is one each. A Second Marker check is one request, and a
long piece of work can take more than one. Limits start again on the 1st.
Check the limits against what Claude costs you: Settings, Usage and cost shows
your real cost per request, so you can see whether a plan covers its own use.

Setting it up (Settings, Plans and payments, super admin only):
  1. Make a Stripe account at stripe.com. Start in Stripe's test mode.
  2. In Stripe: Developers, API keys. Copy the Secret key (sk_test_...) into
     the Secret key box.
  3. In Stripe: Developers, Webhooks, Add endpoint. Paste the webhook address
     shown in Settings (it ends billing.php?a=hook). Choose these events:
       checkout.session.completed
       customer.subscription.created
       customer.subscription.updated
       customer.subscription.deleted
       invoice.payment_failed
     Copy the endpoint's Signing secret (whsec_...) into the Signing secret box.
  4. From the same API keys page, copy the Publishable key (pk_test_...) into
     the Publishable key box. With it, paying, changing the card, cancelling
     and invoices all happen inside the app, in Stripe's own form. Without it,
     people are sent to Stripe's pages instead, and for that you must save
     Stripe's Customer portal settings once (Settings, Billing, Customer portal).
  5. Save keys, then switch on Plans are switched on.
  6. Try it: sign up as a new person from the front page, choose Teacher
     and pay with Stripe's test card 4242 4242 4242 4242 (any future date, any
     three digits). You should come back on Teacher. Cancel it in Manage
     billing and it should say when the plan ends.
  7. When you're happy, swap in the live Secret key (sk_live_...) and the live
     Publishable key (pk_live_...), add the same webhook in Stripe's live mode
     and paste in its Signing secret. The two keys must be a matching pair.

What changes when plans are on:
  - The front page shows a Pricing section, and the terms and privacy pages
    show their paragraphs about payments.
  - New people can sign up on their own. They get their own space (a college
    of one, on Free) and manage it themselves. They can still ask to join a
    college that's already here instead.
  - Someone new who signs in with Google or Microsoft also gets their own Free
    space. So add your colleges' staff in Settings, Team BEFORE they first sign
    in, or they'll end up in a space of their own rather than in their college.
  - Each college's manager gets Settings, Plan and billing: what's used this
    month, the plans, and buttons to pay or manage billing.
  - Colleges you had already set up are on Institution, so nothing changes for
    them. Change any college's plan by hand in Settings, Colleges.
  - When a limit is reached, building stops with a message that says why.
    Nothing is ever deleted. If a paid plan ends the college goes back to Free
    and keeps its people and lessons; it just can't add more people.

Emails the college's manager gets (when email is set up):
  - the plan has started, with what it includes
  - most of the month's builds or checks are used (at 80%), and when all are
  - a payment didn't go through (once, not every time Stripe tries again)
  - the plan has been cancelled, with the date it ends
  - the plan has ended and the account is on Free

Keeping Free accounts from costing you:
  - A ceiling for Free accounts (Settings, Plans and payments): every Free
    account together can make at most this many requests to Claude a month.
    It starts at 1000. The section shows how many have been used and by how
    many accounts. When it's reached, Free accounts are asked to wait for the
    1st or move to a paid plan. Paid plans are not affected. 0 is no ceiling.
  - Someone who signs up on their own with a password must confirm their email
    before anything is built (when email is set up). They see a bar on their
    Start page with Send it again. Signing in with Google or Microsoft already
    proves the address, so those people aren't asked.
  - New sign-ups from one place are limited to 5 a day, and 300 a day in all.

When a limit is reached:
  - The person sees what happened and the next plan up, with its price and a
    button that opens the payment form there and then. People who can't pay
    for the account are told to ask whoever manages it.
  - The Start page shows how much of the month's allowance has been used.

Good to know:
  - Card details never reach your server. This site stores Stripe's reference
    numbers for the customer and subscription, and whether it's paid up.
  - Prices are charged as you set them. VAT or other tax is not added. If you
    need to charge it, switch on Stripe Tax in Stripe.
  - Changing a price affects new payments. People already paying stay on their
    price until they switch plan.
  - Setting a paying college's plan by hand does not change what Stripe charges
    them. Cancel or refund in Stripe if you need to.
  - The wording about payments in terms.html is a starting point. Read it and
    change it to match how you want to handle cancellations and refunds.


PLAIN DOCUMENT NAMES IN TASKS
New lessons number their tasks (Task 1, Task 2), write each step as a full
sentence, and name any document a student makes in plain words that match the
lesson, such as "Unit 3 Task 2 Research analysis" followed by their name. No
underscores or codes. Lessons built before this show old names such as
B_Analysis_Surname as "B Analysis (your surname)" when opened. To get the new
wording in full, regenerate the lesson, or use Regenerate every lesson on the
year planner.


SECOND MARKER: REVIEW AND EXPORT
The last step of Second Marker (the summary, the downloads and the email) is
now drawn by the app itself, like steps 1 to 3, so it looks and behaves like
the rest of Crafticulum. The records, marked copies and emails it makes are
unchanged. The checks (step 4) and the class set card are still drawn by the
marking code, but now have the same cards and numbered headings as the app's
own steps, so the six steps read as one. The marking desk (step 5) is left as
it was on purpose: it is where highlighting and commenting on the work happen.


THE NEW LOGO
Crafticulum's own logo is now the folded page with a C cut into it, with the
name written as craft + iculum. It is used everywhere Crafticulum's own logo
shows: the front page and the other public pages, the sign-in page, the app's
side menu and Start page, student pages, the browser tab icon, the icon when
it's installed as an app, and the picture shown when a link is shared.
A college's own logo and colour still replace it for that college's staff and
students, exactly as before. Browsers and phones keep old icons for a while:
a tab icon can take a refresh or two, and an installed app may need removing
and adding again to pick up the new icon.


A QUICKER START FOR SOMEONE NEW
Someone who signs up on their own is greeted by name, told what their plan
includes, and sees one list of what to do, not the college set-up list as well.
Anyone with no subjects yet can now choose Start with one topic instead of
uploading a specification: they type the subject, level, topic and (if they
like) what students should be able to do, and can build a lesson straight away.
The full specification can be added later.


THE SUPER ADMIN IS NOT PART OF ANY COLLEGE
The super admin sees and can change everything, but belongs to no college,
including the one the site started with.
  - Settings opens on Site overview: every college with its plan, departments,
    people, lessons, requests to Claude this month and when someone last signed
    in, plus the latest activity across the site. Look inside opens a college.
  - The super admin is never counted as one of a college's people, so they
    never take a place on its plan.
  - What the super admin builds is counted for the site, not for the college
    they are looking at. It doesn't come out of that college's allowance, and
    it shows in Usage and cost as its own line.
  - The whole-site limits in Usage and cost still apply to everyone.


COLLEGES: A LIST, THEN INSIDE EACH ONE
Settings, People, Colleges is now a list of every college: its manager,
departments, people and plan. Open one (from there or from Site overview) and
you get that college's own page, where the super admin can change everything
without leaving Settings:
  - its name, contact email, colour and logo
  - its plan and its monthly limit of requests to Claude
  - its managers (add one and they are emailed a link)
  - its departments (rename, add, remove an empty one)
  - its people (who they are, their role and department, when they last
    signed in; add someone new). Changing a role or moving someone is still
    done in Team.
  - the latest activity in it
  - whether its staff can sign in, and removing it once it has no people
Work inside this college opens the app as that college, for its lessons,
planning and results. All colleges takes you back to the list.


SETTINGS IN GROUPS
Settings is now in groups along the top: Overview (super admin), You, People,
College, Teaching, Site (super admin), and Data and backups. Each group shows
only its own parts. Everything, at the end, shows the lot on one page as
before. Links from elsewhere in the app open the right group for you.

THE SUPER ADMIN STANDS OUTSIDE EVERY COLLEGE (v90)
Once the site has more than one college, the super admin signs in to their own
home: Settings, with the site overview, colleges, team, usage, the site's own
settings and backups. No college's name, colour, lessons or planning is shown,
and the workspace screens are hidden. To see inside a college, open it in
Colleges and press Work inside this college. A bar across the top then says
which college you are inside, with Back to super admin to step out again.
Every new sign-in starts outside. On a site with a single college nothing
changes.

TEAM BY COLLEGE (v90)
For the super admin, Team now starts with a College drop-down. Pick one and
its people are listed under each of its departments. Add someone and they go
into the college that is picked. The department list on each person also has
"Move to ..." for moving them to another college.

DELETING A COLLEGE FOR GOOD (v90)
Open a college in Colleges. Under Switch off or remove there is now Delete
this college and everything in it. You type the college's name, press Delete
for good, then press again to confirm. It removes the college's people and
their accounts, its departments, lessons, planning, results, activity log and
the pages given to its students. It can't be undone from the app, so take a
backup first if you might want any of it back. It is refused for the last
college on the site, the one you are working inside, and one that is still
paying by card (cancel its plan first).

NO FLASH OF THE APP BEFORE SIGN-IN (v90)
Opening Sign in or choosing a plan no longer shows the app for a moment before
the right screen appears. A plain cover with the logo stays up until it's ready.

EMAILS IN THE SITE'S OWN LOOK (v91)
Every email the site sends now has the Crafticulum logo and colours, the
subject as a heading, a proper button for each link, and a footer with links
to the site, privacy, terms and contact. The same words are still sent as
plain text too, for mail apps that don't show pictures. The logo is a new
file, mail-logo.png, which sits beside index.html, so upload it with the rest.
Nothing to set up: it uses the mail settings you already have.

WELCOME EMAIL (v91)
Someone who starts their own space (with a password, Google or Microsoft) is
sent a welcome email with three first steps: add your subject, build your
first lesson, teach it and share it. With a password it also carries the
button to confirm their email.

THE COLLEGE MANAGER'S OVERVIEW (v91)
A college manager's Settings now opens on an Overview of their own college:
people, departments, shared lessons and requests this month, how much of the
plan's monthly allowance is used, anyone waiting for approval, and each
department with its head, staff and lessons and a Work in it button. Their
Team list is grouped by department.

SECOND MARKER: THE MARKING DESK (v91)
Step 5 now looks like the other steps: a slim bar for the learner, the mark
sheet and feedback in cards with numbered headings, criteria codes as pills,
and green, red and amber for Y, N and R. Only the look changed. Highlighting,
comments, QuickMarks, focus mode and the keyboard shortcuts work as before.

"CRAFTICULUM AI" (v92)
Everything people read now calls the AI "Crafticulum AI": the app, the front
page, terms, cookies, the emails and the error messages. Mentions of Claude
and "made by Anthropic" have gone. Three places still name Anthropic, on
purpose:
  - Settings, Site setup, where the super admin pastes the key and reads
    error details. Only the super admin sees these.
  - This file and config.example.php, which only you read.
  - One row of the privacy page's list of who handles data. The law expects
    the companies that process people's data to be named, so that row now
    reads "Anthropic, which provides the AI models behind Crafticulum AI".
Teachers no longer see the AI service's own error text. They get a plain
"tell whoever looks after the site", and the detail goes to the super admin.
In Second Marker the model choices are now Most capable, Balanced and Fastest.

NOTIFICATIONS (v93)
Settings, You, Notifications. Each person switches them on for each phone,
tablet or computer they want, and chooses what to hear about:
  - When something finishes: a lesson, a set of lessons or a Second Marker
    check that finishes while they're on another tab or app.
  - Assignment dates: the day before and on the day an assignment is handed
    out, is due in, or has resubmissions due. The dates are the ones in that
    person's own planning.
  - Comments and sign-off, people waiting for approval, messages from the
    contact page, and (for a college's manager) plan limits and payments.
Nothing to set up and no outside service to pay for. The site makes its own
key the first time (kept in data/_vapid.json; don't delete it or everyone has
to switch notifications on again). New file: push-lib.php. The server needs
PHP's OpenSSL and cURL, which nearly every host has.
On an iPhone or iPad, Crafticulum has to be added to the Home Screen first
(Share, Add to Home Screen) and opened from there. That is Apple's rule.
Assignment reminders go out the first time anyone opens the site after 7am.
To send them even on a day nobody signs in, add a scheduled job (cPanel, Cron
Jobs) that opens the address shown at the bottom of Settings, Notifications
once a day a little after 7am, for example:
  5 7 * * * curl -s "PASTE THE ADDRESS HERE" > /dev/null
The same daily run clears out colleges deleted more than 14 days ago.

DELETED COLLEGES ARE KEPT FOR 14 DAYS (v93)
Deleting a college no longer destroys it on the spot. Its people can't sign in
from that moment and its students' pages stop working, but everything is set
aside in data/_deleted for 14 days. Until then it shows under Deleted colleges
in the Colleges list, with Put it back and Remove now. After 14 days it is
removed for good.
A college whose plan has been cancelled can now be deleted straight away, even
while the month it has paid for runs out. One that is still paying is refused
until its plan is cancelled.

FRONT PAGE (v93)
Questions people ask now runs the full width of the page, and the line about
who writes the lessons has gone from the footer.

NO CHANGES TO config.php
None of this needs config.php edited. Everything new is set in Settings.
